
# AWS PostgreSQL Monitoring Stack (Terraform)

This stack provisions:
- VPC (public/private subnets)
- Amazon RDS for PostgreSQL
- EKS Cluster
- Secrets in AWS Secrets Manager
- Monitoring Stack to be deployed on EKS

## Usage
```sh
cd environments/dev
terraform init
terraform apply
```
