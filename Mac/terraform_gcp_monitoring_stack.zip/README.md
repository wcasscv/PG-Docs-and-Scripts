
# GCP PostgreSQL Monitoring Stack (Terraform)

This stack provisions:
- VPC (custom network)
- Cloud SQL for PostgreSQL
- GKE Cluster
- Secrets in Secret Manager
- Monitoring Stack to be deployed on GKE

## Usage
```sh
cd environments/dev
terraform init
terraform apply
```
