
# Azure PostgreSQL Monitoring Stack (Terraform)

This stack provisions:
- VNet and subnets
- Azure Database for PostgreSQL
- AKS Cluster
- Secrets stored in Azure Key Vault
- Monitoring stack deployed on AKS

## Usage
```sh
cd environments/dev
terraform init
terraform apply
```
