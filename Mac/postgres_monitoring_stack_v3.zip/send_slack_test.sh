
#!/bin/bash
# Slack webhook test script

WEBHOOK_URL="$1"
MESSAGE="Test Alert from PostgreSQL Monitoring Stack"

if [ -z "$WEBHOOK_URL" ]; then
  echo "Usage: ./send_slack_test.sh <webhook_url>"
  exit 1
fi

curl -X POST -H 'Content-type: application/json' --data "{
  \"text\": \"$MESSAGE\"
}" $WEBHOOK_URL
