
# PostgreSQL Monitoring Stack (Docker)

This project launches a local observability stack using Docker:
- PostgreSQL
- PostgreSQL Exporter
- Prometheus
- Grafana (with preloaded dashboard + data source)

## Usage

```bash
make up     # start all services
make logs   # stream logs
make down   # stop services
```

Visit:
- Grafana: http://localhost:3000 (admin / admin)
- Prometheus: http://localhost:9090
- PostgreSQL: localhost:5432 (user: postgres / password)

## Folder Structure

- `pgdata/` – persistent volume for PostgreSQL
- `grafana/` – persistent volume for Grafana
- `provisioning/` – datasource and dashboard setup

## Requirements
- Docker + Docker Compose
- Make (optional for Makefile support)
