#!/bin/bash
# PostgreSQL Database Maintenance Activities Script

# Variables
PGUSER="postgres"
PGDATABASE="your_database"
PGHOST="localhost"
PGPORT="5432"
LOGFILE="/var/log/postgres_maintenance.log"
DATE=$(date '+%Y-%m-%d %H:%M:%S')

echo "[$DATE] Starting PostgreSQL maintenance..." | tee -a $LOGFILE

# VACUUM and ANALYZE
echo "[$DATE] Running VACUUM and ANALYZE..." | tee -a $LOGFILE
psql -U $PGUSER -d $PGDATABASE -c "VACUUM ANALYZE;" | tee -a $LOGFILE

# Reindexing tables
echo "[$DATE] Reindexing database..." | tee -a $LOGFILE
psql -U $PGUSER -d $PGDATABASE -c "REINDEX DATABASE $PGDATABASE;" | tee -a $LOGFILE

# Show table bloat estimate
echo "[$DATE] Estimating table bloat..." | tee -a $LOGFILE
psql -U $PGUSER -d $PGDATABASE -c "SELECT schemaname, relname, n_dead_tup FROM pg_stat_user_tables WHERE n_dead_tup > 1000;" | tee -a $LOGFILE

# Reset stats
echo "[$DATE] Resetting statistics..." | tee -a $LOGFILE
psql -U $PGUSER -d $PGDATABASE -c "SELECT pg_stat_reset();" | tee -a $LOGFILE

# Done
echo "[$DATE] PostgreSQL maintenance completed." | tee -a $LOGFILE