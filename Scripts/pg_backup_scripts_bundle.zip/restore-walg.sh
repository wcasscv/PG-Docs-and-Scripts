#!/bin/bash
# Restore PostgreSQL data directory using wal-g
source /etc/wal-g/env.sh
wal-g backup-fetch /var/lib/pgsql/data LATEST