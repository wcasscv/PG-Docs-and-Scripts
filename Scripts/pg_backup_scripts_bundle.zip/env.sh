export WALE_S3_PREFIX=s3://your-s3-bucket/postgres
export AWS_ACCESS_KEY_ID=your_key
export AWS_SECRET_ACCESS_KEY=your_secret
export WALG_COMPRESSION_METHOD=zstd
export PGHOST=/var/run/postgresql
export PGPORT=5432
export PGUSER=postgres